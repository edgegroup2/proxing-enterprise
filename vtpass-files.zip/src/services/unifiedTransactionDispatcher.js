'use strict';

const db = require('../db');
const logger = require('../util/logger');
const { enqueueTransaction } = require('../queues/transactionQueue');

function num(v, d = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : d;
}

function normalizeProductType(value) {
  const v = String(value || '').trim().toLowerCase();

  if (v === 'airtime') return 'airtime';
  if (v === 'data') return 'data';
  if (v === 'tv' || v === 'cable') return 'tv';
  if (v === 'electricity' || v === 'power') return 'electricity';
  if (v === 'waec') return 'waec';
  if (v === 'international-airtime' || v === 'intl-airtime' || v === 'foreign-airtime') {
    return 'international-airtime';
  }

  return v || 'unknown';
}

function makeReference(prefix = 'tx') {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 10)}`;
}

function pickPhone(intent) {
  return (
    intent.phone ||
    intent.target_phone ||
    intent.msisdn ||
    intent.from ||
    null
  );
}

function pickServiceId(intent) {
  return (
    intent.serviceID ||
    intent.serviceId ||
    intent.service_id ||
    intent.network ||
    intent.disco ||
    intent.service ||
    null
  );
}

async function getClient() {
  if (typeof db.connect === 'function') {
    return db.connect();
  }

  if (db.pool && typeof db.pool.connect === 'function') {
    return db.pool.connect();
  }

  throw new Error('Database client connect() is not available');
}

async function getWalletRow(client, userId) {
  const q = await client.query(
    `
      SELECT
        id,
        user_id,
        balance,
        available_balance,
        locked_balance,
        updated_at
      FROM wallets
      WHERE user_id = $1
      LIMIT 1
      FOR UPDATE
    `,
    [userId]
  );

  if (!q.rows.length) {
    throw new Error('Wallet not found');
  }

  return q.rows[0];
}

async function getTransactionRow(client, reference) {
  const q = await client.query(
    `
      SELECT *
      FROM transactions
      WHERE reference = $1
      LIMIT 1
    `,
    [reference]
  );

  return q.rows[0] || null;
}

async function insertTransaction(client, {
  userId,
  reference,
  type,
  amount,
  status,
  channel,
  phone,
  serviceId,
  providerRef,
  meta
}) {
  const q = await client.query(
    `
      INSERT INTO transactions (
        user_id,
        reference,
        type,
        amount,
        status,
        channel,
        phone,
        service_id,
        provider_ref,
        meta,
        created_at,
        updated_at
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,NOW(),NOW())
      RETURNING id, reference, status
    `,
    [
      userId,
      reference,
      type || 'purchase',
      num(amount, 0),
      status || 'pending',
      channel || 'app',
      phone || null,
      serviceId || null,
      providerRef || null,
      meta ? JSON.stringify(meta) : null
    ]
  );

  return q.rows[0];
}

async function updateTransactionStatus(client, {
  reference,
  status,
  providerRef = null,
  meta = null
}) {
  await client.query(
    `
      UPDATE transactions
      SET
        status = $1,
        provider_ref = COALESCE($2, provider_ref),
        meta = COALESCE($3, meta),
        updated_at = NOW()
      WHERE reference = $4
    `,
    [
      status,
      providerRef,
      meta ? JSON.stringify(meta) : null,
      reference
    ]
  );
}

async function applyLedgerDebit(client, {
  userId,
  reference,
  amount,
  narration,
  transactionId = null,
  meta = {}
}) {
  const wallet = await getWalletRow(client, userId);
  const debitAmount = num(amount, 0);

  if (debitAmount <= 0) {
    throw new Error('Invalid transaction amount');
  }

  if (num(wallet.available_balance, 0) < debitAmount) {
    throw new Error('Insufficient wallet balance');
  }

  await client.query(`SET LOCAL app.ledger_update = 'on'`);

  await client.query(
    `
      INSERT INTO ledger_entries (
        user_id,
        wallet_id,
        transaction_id,
        reference,
        type,
        amount,
        narration,
        meta
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `,
    [
      userId,
      wallet.id,
      transactionId,
      reference,
      'debit',
      debitAmount,
      narration || 'Wallet debit',
      JSON.stringify(meta || {})
    ]
  );

  return true;
}

async function applyLedgerCredit(client, {
  userId,
  reference,
  amount,
  narration,
  transactionId = null,
  meta = {}
}) {
  const wallet = await getWalletRow(client, userId);
  const creditAmount = num(amount, 0);

  if (creditAmount <= 0) {
    throw new Error('Invalid refund amount');
  }

  await client.query(`SET LOCAL app.ledger_update = 'on'`);

  await client.query(
    `
      INSERT INTO ledger_entries (
        user_id,
        wallet_id,
        transaction_id,
        reference,
        type,
        amount,
        narration,
        meta
      )
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
    `,
    [
      userId,
      wallet.id,
      transactionId,
      reference,
      'credit',
      creditAmount,
      narration || 'Wallet credit',
      JSON.stringify(meta || {})
    ]
  );

  return true;
}

async function prepareQueuedTransaction(intent) {
  if (!intent || typeof intent !== 'object') {
    throw new Error('Missing transaction intent');
  }

  if (!intent.userId) {
    throw new Error('Missing userId');
  }

  const amount = num(intent.amount, 0);
  if (amount <= 0) {
    throw new Error('Invalid amount');
  }

  const productType = normalizeProductType(intent.productType || intent.service);
  const reference = intent.reference || makeReference(intent.channel || 'tx');

  const phone = pickPhone(intent);
  const serviceId = pickServiceId(intent);

  const client = await getClient();

  try {
    await client.query('BEGIN');

    const txRow = await insertTransaction(client, {
      userId: intent.userId,
      reference,
      type: productType,
      amount,
      status: 'queued',
      channel: intent.channel || 'app',
      phone,
      serviceId,
      providerRef: null,
      meta: {
        queued: true,
        intent
      }
    });

    await applyLedgerDebit(client, {
      userId: intent.userId,
      reference,
      amount,
      narration: `${productType} purchase initiated`,
      transactionId: txRow.id,
      meta: {
        source: 'prepareQueuedTransaction',
        stage: 'debit',
        channel: intent.channel || 'app',
        productType
      }
    });

    await client.query('COMMIT');

const queuedIntent = {
  ...intent,
  userId: intent.userId,
  channel: intent.channel || 'app',
  service: intent.service || normalizeProductType(intent.productType || intent.service),
  productType: normalizeProductType(intent.productType || intent.service),
  network: intent.network || null,
  serviceId: intent.serviceId || intent.service_id || null,
  amount,
  phone: intent.phone || intent.target_phone || null,
  target_phone: intent.target_phone || intent.phone || null,
  meter: intent.meter || intent.billersCode || null,
  billersCode: intent.billersCode || intent.meter || null,
  iuc: intent.iuc || intent.smartcard || null,
  smartcard: intent.smartcard || intent.iuc || null,
  plan: intent.plan || null,
  variation_code: intent.variation_code || intent.variationCode || null,
  disco: intent.disco || null
};

await enqueueTransaction({
  reference,
  channel: queuedIntent.channel || 'app',
  intent: queuedIntent
});

    logger.info({
      type: 'TX_QUEUE_PREPARED',
      reference,
      userId: intent.userId,
      amount,
      productType,
      channel: intent.channel || 'app'
    });

    return {
      queued: true,
      success: true,
      status: 'queued',
      reference,
      amount,
      productType,
      channel: intent.channel || 'app'
    };
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    logger.error({
      type: 'TX_QUEUE_PREPARE_FAILED',
      reference,
      userId: intent.userId,
      error: err.message,
      stack: err.stack
    });

    throw err;
  } finally {
    client.release();
  }
}

async function markWorkerSuccess({
  reference,
  providerRef = null,
  providerPayload = null
}) {
  if (!reference) {
    throw new Error('Missing reference');
  }

  const client = await getClient();

  try {
    await client.query('BEGIN');

    const tx = await getTransactionRow(client, reference);
    if (!tx) {
      throw new Error(`Transaction not found for reference ${reference}`);
    }

    await updateTransactionStatus(client, {
      reference,
      status: 'success',
      providerRef,
      meta: providerPayload || null
    });

    await client.query('COMMIT');

    logger.info({
      type: 'TX_WORKER_MARK_SUCCESS',
      reference,
      providerRef: providerRef || null
    });

    return {
      success: true,
      reference
    };
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    logger.error({
      type: 'TX_WORKER_MARK_SUCCESS_FAILED',
      reference,
      error: err.message,
      stack: err.stack
    });

    throw err;
  } finally {
    client.release();
  }
}

async function markWorkerFailed({
  reference,
  userId = null,
  amount = 0,
  reason = 'Transaction failed',
  providerPayload = null
}) {
  if (!reference) {
    throw new Error('Missing reference');
  }

  const client = await getClient();

  try {
    await client.query('BEGIN');

    const tx = await getTransactionRow(client, reference);
    if (!tx) {
      throw new Error(`Transaction not found for reference ${reference}`);
    }

    const refundAmount = num(amount || tx.amount, 0);
    const refundUserId = userId || tx.user_id;

    const alreadyRefunded =
      tx.meta &&
      typeof tx.meta === 'object' &&
      tx.meta.refunded === true;

    if (!alreadyRefunded && refundAmount > 0 && refundUserId) {
      const refundReference = `${reference}-refund`;

      await applyLedgerCredit(client, {
        userId: refundUserId,
        reference: refundReference,
        amount: refundAmount,
        narration: `Refund for failed transaction ${reference}`,
        transactionId: tx.id,
        meta: {
          source: 'markWorkerFailed',
          originalReference: reference,
          reason
        }
      });

      await updateTransactionStatus(client, {
        reference,
        status: 'failed',
        providerRef: null,
        meta: {
          ...(providerPayload || {}),
          refunded: true,
          refund_reference: refundReference,
          failure_reason: reason
        }
      });
    } else {
      await updateTransactionStatus(client, {
        reference,
        status: 'failed',
        providerRef: null,
        meta: {
          ...(providerPayload || {}),
          refunded: alreadyRefunded,
          failure_reason: reason
        }
      });
    }

    await client.query('COMMIT');

    logger.warn({
      type: 'TX_WORKER_MARK_FAILED',
      reference,
      reason
    });

    return {
      success: true,
      reference,
      status: 'failed'
    };
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {}

    logger.error({
      type: 'TX_WORKER_MARK_FAILED_FATAL',
      reference,
      error: err.message,
      stack: err.stack
    });

    throw err;
  } finally {
    client.release();
  }
}

module.exports = {
  prepareQueuedTransaction,
  markWorkerSuccess,
  markWorkerFailed
};
