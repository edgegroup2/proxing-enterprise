'use strict';

const axios = require('axios');

const BASE_URL = (
  process.env.VTPASS_BASE_URL ||
  'https://vtpass.com/api'
).replace(/\/+$/, '');

function getCredentials() {
  return {
    apiKey: String(process.env.VTPASS_API_KEY || '').trim(),
    secretKey: String(process.env.VTPASS_SECRET_KEY || '').trim(),
    publicKey: String(process.env.VTPASS_PUBLIC_KEY || '').trim(),
  };
}

function buildHeaders() {
  const { apiKey, secretKey, publicKey } = getCredentials();

  return {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'api-key': apiKey,
    'secret-key': secretKey,
    'public-key': publicKey,
  };
}

function normalizeError(err) {
  const status = err?.response?.status || 500;
  const payload = err?.response?.data || null;

  const message =
    payload?.response_description ||
    payload?.message ||
    payload?.error ||
    err?.message ||
    'VTpass request failed';

  const e = new Error(message);
  e.status = status;
  e.payload = payload;

  return e;
}

async function getRequest(path, params = {}) {
  try {
    const response = await axios.get(`${BASE_URL}${path}`, {
      params,
      headers: buildHeaders(),
      timeout: 30000,
    });

    return response.data;
  } catch (err) {
    throw normalizeError(err);
  }
}

async function postRequest(path, body = {}) {
  try {
    const response = await axios.post(`${BASE_URL}${path}`, body, {
      headers: buildHeaders(),
      timeout: 30000,
    });

    return response.data;
  } catch (err) {
    throw normalizeError(err);
  }
}

/**
 * Get VTpass wallet balance
 */
async function getWalletBalance() {
  return getRequest('/balance');
}

/**
 * Fetch service variations
 */
async function serviceVariations(serviceID) {
  if (!serviceID) throw new Error('serviceID required');

  return getRequest('/service-variations', {
    serviceID: String(serviceID).trim(),
  });
}

/**
 * Verify electricity meter / TV IUC
 */
async function merchantVerify({ serviceID, billersCode, type }) {
  return postRequest('/merchant-verify', {
    serviceID,
    billersCode,
    type,
  });
}

/**
 * Purchase product
 */
async function pay(payload) {
  return postRequest('/pay', payload);
}

module.exports = {
  getWalletBalance,
  serviceVariations,
  merchantVerify,
  pay,
};
